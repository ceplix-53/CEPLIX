# ZOIC DDoS Attack Tools 🔥

- **version 4.0 ✅**
- **Add Layer3 Attack ✅**

# DoxGroup 😈
**https://rvlt.gg/A6n8QXVN**

# ScreenShot📷:
![image](https://github.com/user-attachments/assets/a4366d63-5841-4205-bdb0-70abd6214f16)

# LAYER 3 🔥
![image](https://github.com/user-attachments/assets/54d690bc-2c48-427d-96ef-00bd59f37e34)
![image](https://github.com/user-attachments/assets/1d0c724e-b892-44fe-ae16-7b2c72a06de9)




# LAYER 4 🔥
![image](https://github.com/user-attachments/assets/0deadccc-10b6-46cd-93f2-1ff7d08ff3b9)
![image](https://github.com/user-attachments/assets/e2b21be6-9461-4abb-9224-35ccb14ad7c7)





# LAYER 7 🔥
![image](https://github.com/user-attachments/assets/5e0da7cb-7372-4357-9983-9bddd83a8bbd)
![image](https://github.com/user-attachments/assets/1a00cf86-0d39-42ea-ad91-4b299877a3d2)






# HOW TO USE ❓
```
git clone https://github.com/madanokr001/ZOIC-DDoS.git
```
```
cd ZOIC-DDoS/ZOIC
```
```
ls
```
```
python zoic.py
```

## WINDOWS ✅
## LINUX ✅ 

# About 🤑
**We greatly appreciate your feedback and suggestions. Please feel free to share any thoughts you may have; your input is invaluable to us!**






